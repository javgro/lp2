use Negocios2023
go

--Procedures--
--1. Un procedure, donde liste los registros de tb_pedidoscabe y tb_clientes por un determinado empleado (idempleado), 
--definiendo los par�metros @id. En el procedimiento almacenado,
--liste los campos idpedido, fechapedido, nombrecia (tb_clientes), direccionDestinatario y CiudadDestinatario.
CREATE or ALTER PROCEDURE ListarPedidosPorEmpleados
    @id INT
AS
BEGIN
    SELECT pc.idpedido, pc.fechapedido, c.nombrecia, pc.direccionDestinatario, pc.CiudadDestinatario
    FROM tb_pedidoscabe pc
    INNER JOIN tb_clientes c ON pc.idcliente = c.idcliente
    WHERE pc.idempleado = @id;
END
GO



--1. Un procedure para listar los registros de tb_empleados (idempleado y nomEmpleado)
CREATE or ALTER PROCEDURE usp_listarempleados
AS
    SELECT idempleado, nomEmpleado
    FROM tb_empleados;
GO


EXEC usp_listarempleados;
go

--2. Un procedure donde permita listar los registros de la tabla tb_clientes y un procedure donde liste los registros de tb_paises

create or alter proc usp_clientes
As
Select * from tb_clientes
go
--
create or alter proc usp_paises
As
Select * from tb_paises
go

--2. Un procedure donde permita agregar un registro a la tabla tb_clientes, defina sus par�metros.
create or alter procedure usp_insertar_clientes
@nombrecia varchar(40),
@direccion varchar(60),
@idpais int,
@telefono varchar(24)
As
declare @vidcliente int
set @vidcliente=(select max(idCliente) +1
from tb_clientes)
insert into tb_clientes(IdCliente, NombreCia, Direccion, idpais, Telefono)
VALUES (@vidcliente,@nombrecia,@direccion,@idpais,@telefono)
go


--otro modelo
CREATE or alter PROCEDURE usp_inserta_clientes
@idcliente varchar(40),
@nombrecia varchar(40),
@direccion varchar(60),
@idpais int,
@telefono varchar(24) 
AS
BEGIN
INSERT INTO tb_clientes  (idcliente, nombrecia, direccion, idpais, telefono)
VALUES(@idcliente, @nombrecia, @direccion, @idpais, @telefono)
SELECT  idcliente = @idcliente, nombrecia = @nombrecia, direccion = @direccion,idpais = @idpais,
telefono=@telefono
FROM tb_clientes�
END
go



--2. Un procedure donde permita actualizar un registro a la tabla tb_clientes por su campo idcliente, defina sus par�metros.
create or alter procedure usp_actualizar_clientes
@idcliente int,
@nombrecia varchar(40),
@direccion varchar(60),
@idpais int,
@telefono varchar(24)
As
update tb_clientes
Set NombreCia=@nombrecia, direccion=@direccion,
idpais=@idpais, Telefono=@telefono
where IdCliente= @idcliente
go


