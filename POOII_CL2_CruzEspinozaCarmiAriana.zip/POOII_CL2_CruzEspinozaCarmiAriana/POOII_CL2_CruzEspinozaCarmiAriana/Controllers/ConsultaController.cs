﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using POOII_CL2_CruzEspinozaCarmiAriana.Models;


namespace POOII_CL2_CruzEspinozaCarmiAriana.Controllers
{
    public class ConsultaController : Controller
    {
        // GET: Consulta
        public IEnumerable<Empleado> listarEmpleados()
        {
            List<Empleado> empleados = new List<Empleado>();

            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString))
            {
                cn.Open();

                SqlCommand cmd = new SqlCommand("usp_listarempleados", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    empleados.Add(new Empleado()
                    {
                        idempleado = dr.GetInt32(dr.GetOrdinal("idempleado")),
                        nomempleado = dr.GetString(dr.GetOrdinal("nomEmpleado"))
                    });
                }

                dr.Close();
            }

            return empleados;
        }

        public IEnumerable<Pedido> consultarPedidos(int id)
        {

            List<Pedido> pedidos = new List<Pedido>();

            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString))
            {
                cn.Open();


                string query = "EXEC usp_ListarPedidosPorEmpleados @id";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.Parameters.AddWithValue("@id", id);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    pedidos.Add(new Pedido()
                    {
                        idpedido = dr.GetInt32(dr.GetOrdinal("idpedido")),
                        fecha = dr.GetDateTime(dr.GetOrdinal("fechapedido")),
                        nombrecia = dr.GetString(dr.GetOrdinal("nombrecia")),
                        direcciondes = dr.GetString(dr.GetOrdinal("direccionDestinatario")),
                        ciudaddest = dr.GetString(dr.GetOrdinal("CiudadDestinatario"))
                    });
                }

                dr.Close();
            }

            return pedidos;
        }
        //List c
        public IEnumerable<Cliente> listadoClientes()
        {
            List<Cliente> clientes = new List<Cliente>();
            using (SqlConnection cn = new SqlConnection(
                ConfigurationManager.ConnectionStrings["sql"].ConnectionString))
            {
             cn.Open();
                SqlCommand cmd = new SqlCommand("usp_clientes", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    clientes.Add(new Cliente()
                    {
                        idcliente = dr.GetString(0),
                        nombrecia = dr.GetString(1),
                        direccion = dr.GetString(2),
                        idpais = dr.GetString(3),
                        telefono = dr.GetString(4)
                    });
                }
                dr.Close();
            }
            return clientes;
        }

        //List p
        public IEnumerable<Pais> listadoPaises()
        {
            List<Pais> paises = new List<Pais>();
            using (SqlConnection cn = new SqlConnection(
                ConfigurationManager.ConnectionStrings["sql"].ConnectionString))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("usp_paises", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    paises.Add(new Pais()
                    {
                        idpais = dr.GetString(0),
                        nompais = dr.GetString(1),
                    });
                }
                dr.Close();
            }
            return paises;
        }
        //agregar
        public string insert(Cliente reg)
        {
            string mensaje = "";
            using (SqlConnection cn = new SqlConnection(
             ConfigurationManager.ConnectionStrings["sql"].ConnectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("usp_inserta_clientes", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@idCliente", reg.idcliente);
                    cmd.Parameters.AddWithValue("@nombrecia", reg.nombrecia);
                    cmd.Parameters.AddWithValue("@direccion", reg.direccion);
                    cmd.Parameters.AddWithValue("@idpais", reg.idpais);
                    cmd.Parameters.AddWithValue("@telefono", reg.telefono);
                    cn.Open();
                    int i = cmd.ExecuteNonQuery();
                    mensaje = $"Se ha insertado {i} cliente";
                }
                catch (Exception ex) { mensaje = ex.Message; }
                finally { cn.Close(); }
            }
            return mensaje;

        }
        //actualizar
        public string actualizar(Cliente reg)
        {
            string mensaje = "";
            using (SqlConnection cn = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["sql"].ConnectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("usp_actualizar_clientes", cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@idCliente", reg.idcliente);
                    cmd.Parameters.AddWithValue("@nombrecia", reg.nombrecia);
                    cmd.Parameters.AddWithValue("@direccion", reg.direccion);
                    cmd.Parameters.AddWithValue("@idpais", reg.idpais);
                    cmd.Parameters.AddWithValue("@telefono", reg.telefono);
                    cn.Open();
                    int i = cmd.ExecuteNonQuery();
                    mensaje = $"Se ha actualizado {i} registro";
                }
                catch (Exception ex) { mensaje = ex.Message; }
                finally { cn.Close(); }
            }
            return mensaje;
        }


        public ActionResult ListaConsultaPedidos(int id = 0)
        {
            ViewBag.Empleados = new SelectList(listarEmpleados(), "idempleado", "nomEmpleado");
            return View(consultarPedidos(id));
        }

        //
        public ActionResult VistalistadoClientes()
        {
            return View(listadoClientes());
        }
        //
        public ActionResult Create()
        {
            ViewBag.paises = new SelectList(listadoPaises(), "idpais", "nompais");
            return View(new Cliente());
        }
        [HttpPost]public ActionResult Create(Cliente reg)
        {
            if (!ModelState.IsValid)
            {
                return View(reg);
            }
            ViewBag.mensaje = insert(reg);
            ViewBag.paises = new SelectList(listadoPaises(), "idpais", "nompais", reg.idpais);
            return View(reg);


        }
        //edit
        
        [HttpPost]public ActionResult Edit(Cliente reg)
        {
            if (!ModelState.IsValid)
            {
                return View(reg);
            }
            ViewBag.mensaje = actualizar(reg);
            return View(reg);
        }
    }
}