﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POOII_CL2_CruzEspinozaCarmiAriana.Models
{
    public class Pedido
    {
        public int idpedido { get; set; }
        public DateTime fecha { get; set; }
        public string nombrecia { get; set; }
        public string direcciondes { get; set; }
        public string ciudaddest { get; set; }
    }
}