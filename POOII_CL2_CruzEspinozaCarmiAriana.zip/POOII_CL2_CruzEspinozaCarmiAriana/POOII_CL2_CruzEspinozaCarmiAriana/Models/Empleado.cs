﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POOII_CL2_CruzEspinozaCarmiAriana.Models
{
    public class Empleado
    {
        public int idempleado { get; set; }
        public string nomempleado { get; set; }
    }
}