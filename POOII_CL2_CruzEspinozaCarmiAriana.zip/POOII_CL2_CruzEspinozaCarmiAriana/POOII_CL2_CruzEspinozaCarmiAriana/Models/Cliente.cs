﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POOII_CL2_CruzEspinozaCarmiAriana.Models
{
    public class Cliente
    {
        public string idcliente { get; set; }
        public string nombrecia { get; set; }
        public string  direccion { get; set; }
        public string  idpais { get; set; }
        public string telefono { get; set; }

    }
}